namespace BulkDataverseDownload
{
    /// <summary>
    /// Bulk dataverse constants
    /// </summary>
    public static class BDDConstants
    {
        public const string EntityLtrTransactionLogicalName = "ltr_transaction";
        public const string EntityBulkDownloadReport = "cr54e_bulkdownloadreport";
        //bulk download report data
        public const string ColumnReportData = "cr54e_reportdata";

        //ltr columns
        public const string ColumnProductCode = "ltr_product_code";
        public const string ColumnBranchCode = "ltr_branch_code";
        public const string ColumnTransactionDesc = "ltr_transaction_description";

        //message params
        public const string MsgOutcometbdFile = "tbd_file";
        public const string MsgInputBranchCode = "branchcode";
        public const string MsgInputBranchCodeOperation = "branchcodeoperation";
    }
}
