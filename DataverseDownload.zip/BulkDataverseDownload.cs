﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Extensions;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using static System.Net.Mime.MediaTypeNames;

namespace BulkDataverseDownload
{
    /// <summary>
    /// This class is used perform query on dataverse and retrive data in the format of downLoadCsvText
    /// </summary>
    public class BulkDataverseDownload : IPlugin
    {
        private static ITracingService tracingService;
        public void Execute(IServiceProvider serviceProvider)
        {
            tracingService = (ITracingService)
                serviceProvider.GetService(typeof(ITracingService));
            try
            {
                var context = (IPluginExecutionContext)
                    serviceProvider.GetService(typeof(IPluginExecutionContext));
                tracingService.Trace(
                    $"Execution started for custom api cr54e_BulkDataverseDownload, context user id${context.UserId}"
                );
                var serviceFactory = (IOrganizationServiceFactory)
                    serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                var service = serviceFactory.CreateOrganizationService(
                context.UserId);
                var queryExp = GetQueryExpression(context);
                var filteredEntities = BulkDataverseDownloadHelpers.RetrieveAll(
                    service,
                    tracingService,
                    queryExp
                );
                tracingService.Trace($"Total Records Fetched: {filteredEntities.Count()}");

                var csv = GetCsvFromEntities(tracingService, filteredEntities);

                //filling csv with more than 100MB
                //for (var a = 0; a < 7; a++)
                //{
                //    csv.AppendLine(csv.ToString());
                //}
                //var csvTobeAppeneded = GetCsvFromEntities(tracingService, filteredEntities).ToString();
                //for (var b = 0; b < 45; b++)
                //{
                //    csv.Append(csvTobeAppeneded);
                //}

                int byteCount = System.Text.Encoding.UTF8.GetByteCount(csv.ToString());
                tracingService.Trace($"csv data of size in kb: {byteCount / 1024}.");
                //UpdateColumn(service);
                var newRecordGuid = ConvertCsvToStreamAndUpload(csv.ToString(), service);
                context.OutputParameters[BDDConstants.MsgOutcometbdFile] = newRecordGuid;
                tracingService.Trace("cr54e_BulkDataverseDownload completed setting output params");
            }
            catch (Exception ex)
            {
                tracingService.Trace($"Execution failed cr54e_BulkDataverseDownload .{ex.Message}");
            }
        }
        private static void UpdateColumn(IOrganizationService service)
        {
            FileAttributeMetadata fileColumn = new FileAttributeMetadata()
            {
                SchemaName = BDDConstants.ColumnReportData,
                DisplayName = new Label("downloadreport1", 1033),
                RequiredLevel = new AttributeRequiredLevelManagedProperty(
                   AttributeRequiredLevel.None),
                Description = new Label("Download Report1 file column", 1033),
                MaxSizeInKB = 130 * 1024 // 400 MB

            };
            CreateAttributeRequest createfileColumnRequest = new CreateAttributeRequest();
            createfileColumnRequest.Attribute = fileColumn;
            createfileColumnRequest.EntityName = BDDConstants.EntityBulkDownloadReport;
            var response = service.Execute(createfileColumnRequest);

            ///*
            //            // Create the request
            //            RetrieveAttributeRequest attributeRequest = new RetrieveAttributeRequest
            //            {
            //                EntityLogicalName = BDDConstants.EntityBulkDownloadReport,
            //                LogicalName = BDDConstants.ColumnReportData,
            //                RetrieveAsIfPublished = true
            //            };

            //            // Execute the request using IOrganizationService instance
            //            RetrieveAttributeResponse attributeResponse =
            //                (RetrieveAttributeResponse)service.Execute(attributeRequest);

            //            tracingService.Trace("Retrieved the attribute {0}.",
            //                attributeResponse.AttributeMetadata.SchemaName);

            //            FileAttributeMetadata fAttrMeta = (FileAttributeMetadata)attributeResponse.AttributeMetadata;
            //            fAttrMeta.MaxSizeInKB = 400 * 1024;



            //            // Update an attribute retrieved via RetrieveAttributeRequest
            //            UpdateAttributeRequest updateRequest = new UpdateAttributeRequest
            //            {
            //                Attribute = fAttrMeta,
            //                EntityName = BDDConstants.EntityBulkDownloadReport,
            //                MergeLabels = false
            //            };

            //            // Execute the request using IOrganizationService instance
            //            service.Execute(updateRequest);
            //*/
            //            tracingService.Trace("created the new file column attribute");
            //
        }
        private static QueryExpression GetQueryExpression(IPluginExecutionContext context)
        {
            var queryExp = new QueryExpression
            {
                EntityName = BDDConstants.EntityLtrTransactionLogicalName,
                ColumnSet = new ColumnSet(
                    BDDConstants.ColumnProductCode,
                    BDDConstants.ColumnBranchCode,
                    BDDConstants.ColumnTransactionDesc
            )
            };
            if (context.InputParameters[BDDConstants.MsgInputBranchCodeOperation].Equals("Equal"))
            {
                queryExp.Criteria.AddCondition(BDDConstants.ColumnBranchCode,
                    ConditionOperator.Equal,
                   $"{context.InputParameters[BDDConstants.MsgInputBranchCode]}");
                return queryExp;
            }

            queryExp.Criteria.AddCondition(BDDConstants.ColumnBranchCode,
                ConditionOperator.NotEqual,
               $"{context.InputParameters[BDDConstants.MsgInputBranchCode]}");
            return queryExp;
        }

        private static StringBuilder GetCsvFromEntities(ITracingService tracingService,
         IEnumerable<Entity> entitiesFetched)
        {
            var downLoadCsvText = new StringBuilder();
            downLoadCsvText.AppendLine($"Id," +
                $"{BDDConstants.ColumnProductCode}," +
                $"{BDDConstants.ColumnBranchCode}," +
                $"{BDDConstants.ColumnTransactionDesc}");
            tracingService.Trace("cr54e_BulkDataverseDownload fetched the records");
            foreach (var entity in entitiesFetched)
            {
                downLoadCsvText.AppendLine(
                    $"{entity.Id}," +
                    $"{entity[BDDConstants.ColumnProductCode]}," +
                    $"{entity[BDDConstants.ColumnBranchCode]}," +
                    $"{entity[BDDConstants.ColumnTransactionDesc]}"
                );
            }

            return downLoadCsvText;
        }

        private static Guid ConvertCsvToStreamAndUpload(string csvData, IOrganizationService service)
        {
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);
            writer.Write(csvData);
            writer.Flush();
            stream.Position = 0;
            var fileName = $"{DateTime.Now.ToString().Replace("/", "").Replace(":", "").Replace(" ", "")}";
            Entity downloadReport = new Entity(BDDConstants.EntityBulkDownloadReport);
            downloadReport["cr54e_name"] = fileName;
            var createdDownloadReportGuid = service.Create(downloadReport);
            tracingService.Trace("Created record in bulk download report table.");
            EntityReference newlyCreatedRecord = new EntityReference(BDDConstants.EntityBulkDownloadReport, createdDownloadReportGuid);
            var fileNameWithExt = $"{fileName}.csv";
            UploadFile(stream, fileNameWithExt, "text/csv", newlyCreatedRecord, BDDConstants.ColumnReportData, service);
            return newlyCreatedRecord.Id;
        }

        private static Guid UploadFile(Stream stream,
            string fileName,
            string mimeType,
            EntityReference target,
            string fileAttributeName,
            IOrganizationService organizationService)
        {
            tracingService.Trace("Started uploading file.");
            var initializeUploadRequest = new InitializeFileBlocksUploadRequest
            {
                FileAttributeName = fileAttributeName,
                FileName = fileName,
                Target = target
            };

            var initializeUploadResponse = (InitializeFileBlocksUploadResponse)organizationService.Execute(initializeUploadRequest);

            const int blockSize = 4194304; 
            int byteCount;
            var blockList = new List<string>();

            do
            {
                var buffer = new byte[blockSize];
                byteCount = stream.Read(buffer, 0, blockSize);

                if (byteCount < blockSize)
                    Array.Resize(ref buffer, byteCount);

                var uploadRequest = new UploadBlockRequest
                {
                    BlockData = buffer,
                    BlockId = Convert.ToBase64String(Encoding.UTF8.GetBytes(Guid.NewGuid().ToString("N"))),
                    FileContinuationToken = initializeUploadResponse.FileContinuationToken
                };

                organizationService.Execute(uploadRequest);
                tracingService.Trace("Executed chunk during file upload.");
                blockList.Add(uploadRequest.BlockId);
            } while (byteCount == blockSize);

            var commitRequest = new CommitFileBlocksUploadRequest
            {
                BlockList = blockList.ToArray(),
                FileContinuationToken = initializeUploadResponse.FileContinuationToken,
                FileName = initializeUploadRequest.FileName,
                MimeType = mimeType
            };
            tracingService.Trace("Initiating commit request.");
            var commitResponse = (CommitFileBlocksUploadResponse)organizationService.Execute(commitRequest);
            tracingService.Trace("Executed commit request for bulk upload.");
            return commitResponse.FileId;
        }
    }
}

