﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;

internal static class BulkDataverseDownloadHelpers
{
    internal static IEnumerable<Entity> RetrieveAll(IOrganizationService service, ITracingService tracingService, QueryExpression queryExp)
    {
        return GetEntities(service, tracingService, queryExp);
    }

    private static IEnumerable<Entity> GetEntities(this IOrganizationService service,
        ITracingService tracingService, QueryExpression query)
    {
        var result = new List<Entity>();
        var entities = service.RetrieveMultiple(query);
        result.AddRange(entities.Entities);
        var page = 2;
        tracingService.Trace($"GetEntities started for {page}");
        while (entities.MoreRecords)
        {
            query.PageInfo = new PagingInfo
            {
                PagingCookie = entities.PagingCookie,
                PageNumber = page,
                Count = 5000
            };

            entities = service.RetrieveMultiple(query);
            result.AddRange(entities.Entities);
            tracingService.Trace($"GetEntities Added entities after getting multiple entities {page}");
            page++;
        }
        return result;
    }
}